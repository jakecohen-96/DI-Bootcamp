const products = [
    { id: 101, name: "iPhone", price: 800 },
    { id: 201, name: "iPad", price: 700 },
    { id: 301, name: "iWatch", price: 600 },
  ];

  module.exports = {
    products
  }