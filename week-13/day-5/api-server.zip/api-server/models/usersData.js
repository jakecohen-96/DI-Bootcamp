const users = [
    { id: 101, name: "A" },
    { id: 201, name: "B" },
    { id: 301, name: "C" },
  ];

  module.exports = {
    users
  }
