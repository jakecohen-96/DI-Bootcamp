import _Button from "./_Button";
const Action = () => {

  return (
    <>
      <h2>Action Button</h2>
      <_Button />
    </>
  );
};
export default Action;
