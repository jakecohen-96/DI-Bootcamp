import ShowCouter from "./ShowCouter";
const Display = () => {
   
  return (
    <>
      <h2>Counter Display</h2>
      <ShowCouter />
    </>
  );
};
export default Display;
