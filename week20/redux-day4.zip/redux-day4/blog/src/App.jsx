import "./App.css";
import PostsList from "./features/posts/PostsList";
function App() {
  return (
    <>
      <PostsList />
    </>
  );
}

export default App;
